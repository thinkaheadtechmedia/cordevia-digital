================================================================================
CORDEVIA DIGITAL — OFFICIAL SOCIAL MEDIA PROFILE PICTURE ASSET PACK
================================================================================
Agency: Cordevia Digital (Formerly Tarana Group)
Website: https://cordeviadigital.com
Identity: Media-Tech Engineering, YouTube Scale, Algorithmic SEO & Web Systems
Version: 2.4 (High-Resolution Master Suite)

--------------------------------------------------------------------------------
1. RECOMMENDED PLATFORM UPLOAD SPECS
--------------------------------------------------------------------------------
• YouTube Channel Icon:
  - Required Size: 800 x 800 px (Circular Crop)
  - Recommended File: cordevia-avatar-circular-1024x1024.svg or rendered PNG
  - Safe Zone: Centered within 80% circle diameter (already calibrated)

• X / Twitter Profile Picture:
  - Required Size: 400 x 400 px (Circular Crop)
  - Recommended File: cordevia-avatar-circular-1024x1024.svg or rendered PNG

• LinkedIn Company Page Logo:
  - Required Size: 400 x 400 px (Square / Circular)
  - Recommended File: cordevia-social-profile-picture-1024x1024.svg

• Instagram Profile Picture:
  - Required Size: 320 x 320 px (Circular Crop)
  - Highlight Story Ring: Compatible with native gradient borders

• TikTok Profile Picture:
  - Required Size: 200 x 200 px (Circular Crop)

• WhatsApp Business & Telegram Channel / Store:
  - Required Size: 500 x 500 px or 1024 x 1024 px
  - Profile avatar for @CordeviaStore and @CordeviaStoreBot

--------------------------------------------------------------------------------
2. COLOR PALETTE & CODES
--------------------------------------------------------------------------------
• Primary Electric Cyan:  #06B6D4 (RGB: 6, 182, 212)
• Celestial Teal:         #14B8A6 (RGB: 20, 184, 166)
• Neon Emerald:           #10B981 (RGB: 16, 185, 129)
• Sky Highlight:          #38BDF8 (RGB: 56, 189, 248)
• Cosmic Obsidian Base:   #04060A to #0E1726
• Text / Light Specular:  #FFFFFF and #F8FAFC

--------------------------------------------------------------------------------
3. HOW TO USE THESE ASSETS
--------------------------------------------------------------------------------
• For SVG-compatible platforms: Directly upload the SVG files for infinite clarity.
• For PNG uploads: You can use the in-app Social Avatar Studio at:
  https://ais-pre-dbzrdxi2ld4xyxy453x4le-171458272362.europe-west1.run.app
  to instantly generate 1024x1024, 800x800, or 400x400 PNGs with 1 click!

All rights reserved © Cordevia Digital.
